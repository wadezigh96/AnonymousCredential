import { groth16 } from "snarkjs";
import { buildPoseidon } from "circomlibjs";
import { IMT } from "@zk-kit/imt";

const rand = () => BigInt("0x" + [...crypto.getRandomValues(new Uint8Array(31))].map(b => b.toString(16).padStart(2, "0")).join(""));

export async function newIdentity() {
  const p = await buildPoseidon();
  const secret = rand(), nullifierSecret = rand();
  const commitment = p.F.toObject(p([secret, nullifierSecret])) as bigint;
  return { secret, nullifierSecret, commitment }; // simpan secret di browser saja
}

// commitments: semua event Registered, urut berdasarkan index
export async function prove(id: Awaited<ReturnType<typeof newIdentity>>, commitments: bigint[], scope: bigint, messageHash: bigint) {
  const p = await buildPoseidon();
  const hash = (v: bigint[]) => p.F.toObject(p(v)) as bigint;
  const tree = new IMT(hash, 16, 0n, 2, commitments);
  const mp = tree.createProof(tree.indexOf(id.commitment));
  const { proof: pf, publicSignals } = await groth16.fullProve(
    { secret: id.secret, nullifierSecret: id.nullifierSecret,
      siblings: mp.siblings.map((s: bigint[]) => s[0]), bits: mp.pathIndices,
      merkleRoot: tree.root, scope, messageHash },
    "/anon.wasm", "/anon.zkey");
  return {
    a: [pf.pi_a[0], pf.pi_a[1]],
    b: [[pf.pi_b[0][1], pf.pi_b[0][0]], [pf.pi_b[1][1], pf.pi_b[1][0]]],
    c: [pf.pi_c[0], pf.pi_c[1]],
    root: tree.root as bigint, nullifier: BigInt(publicSignals[0]),
  };
}
